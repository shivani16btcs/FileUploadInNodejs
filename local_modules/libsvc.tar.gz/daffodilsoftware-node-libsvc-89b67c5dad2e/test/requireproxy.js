// proxyquire configured for isolated tests
module.exports = require('proxyquire').noPreserveCache().noCallThru();
